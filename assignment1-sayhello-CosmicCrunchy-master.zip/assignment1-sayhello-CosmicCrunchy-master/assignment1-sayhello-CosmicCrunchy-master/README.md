# Assignment 1 - Say Hello

If you haven't already...
- Create a GitHub account
- Install VS Code
- Install Git
- Install the GitHub Classroom extension
(these steps are covered in the Module 1 Lecture Video)

Accept the assignment using the link in Canvas and complete the steps below from within VS Code (using the GitHub Classroom extension).

1. Replace the ? with your name in the index.html file
2. Change the color of the greeting text from within the style.css file.
3. Send a Direct Message on Discord to Dr. Sheffield with the word that prints to the console when you open the index.html page in your browser.

**To submit:**
1. Stage, commit, and sync your changes before the due date using the Source Control panel in VS Code.  
2. Submit your GitHub username in the text entry field on the Canvas assignment to notify Dr. Sheffield that it is ready for review.